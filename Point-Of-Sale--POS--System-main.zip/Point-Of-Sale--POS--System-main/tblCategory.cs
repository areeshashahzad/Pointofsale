//------------------------------------------------------------------------------
// 

namespace NewPOS
{
    using System;
    using System.Collections.Generic;
    
    public partial class tblCategory
    {
        public tblCategory()
        {
            this.tblProduct = new HashSet<tblProduct>();
        }
    
        public int categoryId { get; set; }
        public string CategoryName { get; set; }
        public byte[] categoryImage { get; set; }
    
        public virtual ICollection<tblProduct> tblProduct { get; set; }
    }
}
