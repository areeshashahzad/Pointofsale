//------------------------------------------------------------------------------
//

namespace NewPOS
{
    using System;
    using System.Collections.Generic;
    
    public partial class tblProduct
    {
        public tblProduct()
        {
            this.tblTransactionItem = new HashSet<tblTransactionItem>();
        }
    
        public int productId { get; set; }
        public string productName { get; set; }
        public Nullable<decimal> productPrice { get; set; }
        public byte[] productImage { get; set; }
        public Nullable<int> categoryId { get; set; }
    
        public virtual tblCategory tblCategory { get; set; }
        public virtual ICollection<tblTransactionItem> tblTransactionItem { get; set; }
    }
}
