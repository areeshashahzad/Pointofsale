//------------------------------------------------------------------------------

namespace NewPOS
{
    using System;
    using System.Collections.Generic;
    
    public partial class tblTransactionItem
    {
        public int transactionItemId { get; set; }
        public Nullable<int> transactionId { get; set; }
        public Nullable<int> productId { get; set; }
        public Nullable<int> userId { get; set; }
    
        public virtual tblProduct tblProduct { get; set; }
        public virtual tblTransaction tblTransaction { get; set; }
        public virtual tblUsers tblUsers { get; set; }
    }
}
