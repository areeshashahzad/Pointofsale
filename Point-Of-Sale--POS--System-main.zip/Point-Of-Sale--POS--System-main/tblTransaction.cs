//------------------------------------------------------------------------------
/
namespace NewPOS
{
    using System;
    using System.Collections.Generic;
    
    public partial class tblTransaction
    {
        public tblTransaction()
        {
            this.tblTransactionItem = new HashSet<tblTransactionItem>();
        }
    
        public int transactionId { get; set; }
        public Nullable<System.DateTime> transactionDate { get; set; }
    
        public virtual ICollection<tblTransactionItem> tblTransactionItem { get; set; }
    }
}
