 
We have used LINQ queries

// select a product
from p in dbe.tblProduct where p.categoryId == categoryID select p




// SignIN  
// dbe is the instance of my database and tblUsers is the table that stores user information such as name email and password
Database1Entities dbe = new Database1Entities();
foreach (var p in dbe.tblUsers)
            {
                if (p.userName == txtUserName.Text && p.password == txtPassword.Text)
                {
                    MessageBox.Show("Successfully Logged In");
		}
	   }




// to register a new user
Database1Entities dbe = new Database1Entities();
tblUsers l = new tblUsers();
// logic to check username already exists or empty username or password and then
l.userName = txtUserNameReg.Text;
l.password = txtPasswordReg.Text;
l.name = txtNameReg.Text;
l.surname = txtSurnameReg.Text;
l.email = txtEmailReg.Text;
dbe.tblUsers.Add(l);
dbe.SaveChanges();



// view all products
dataGridView1.DataSource = dbe.tblProduct.ToList();



// select a specific catagory of products
var data = from p in dbe.tblProduct where p.categoryId == (int)cmbFilterCategory.SelectedIndex + 1 select p;
var dataList = data.ToList();
dataGridView1.DataSource = dataList;



// ADD a New Product

tblProduct pro = new tblProduct();

pro.productName = txtProductName.Text;

pro.productPrice = decimal.Parse(txtProductPrice.Text);

pro.categoryId = (int)cmbSelectCategoryAddProduct.SelectedValue;

pro.productImage = dataProduct;

dbe.tblProduct.Add(pro);

dbe.SaveChanges();

MessageBox.Show("Product Saved");



// Add a new Catagory
 tblCategory cat = new tblCategory();

 cat.CategoryName = txtCategoryName.Text;

cat.categoryImage = dataCategory;

dbe.tblCategory.Add(cat);

dbe.SaveChanges();

MessageBox.Show("Category Saved");
